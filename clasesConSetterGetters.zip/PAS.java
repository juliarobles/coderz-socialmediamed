package modelo;

public class PAS extends Usuario {
	public enum ocupacion{ //completar con m�s
		Conserje, Secretario
	}
	
}
