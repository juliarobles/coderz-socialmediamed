package modelo;

public class Asignatura {
	public int codAsig;
	public String nombre;
	public String curso; //EJ 17-18, 19-20
	
	public int getcodAsig() {
		return codAsig;
	}
	public void setcodAsig(int codAsig) {
		this.codAsig = codAsig;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso) {
		this.curso = curso;
	}
	
	
}
