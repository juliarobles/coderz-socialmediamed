package modelo;

public class ONG {
	public String correo;
	public String contrase�a;
	public String nombre;
	public String descripcion;
}
