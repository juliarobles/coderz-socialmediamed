package modelo;

public class PDI extends Usuario {
	public enum cargo{
		profesor, investigador
	}
	public Asignatura[] asigImpartidas;
	
	public Asignatura[] getAsigImpartidas() {
		return asigImpartidas;
	}
	public void setAsigImpartidas(Asignatura[] asigImpartidas) {
		this.asigImpartidas = asigImpartidas;
	}
}
