package modelo;


public class Alumno extends Usuario {
	public String imagenUrl;
	public String descripcion;
	
	public enum titulacion { //A�adir m�s titulaciones
		Medicina, Enfermeria
	}
	private enum idioma{ //A�adir todos los idiomas
		Espa�ol, Ingles, Frances
	}
	public idioma[] idiomas;
	public enum disponibilidad{ //Mejorar con fechas concretas
		Siempre, Parcial, Nunca
	}
	public enum zonaAccion{
		Local, Nacional, Internacional
	}
	
	public Asignatura[] asigCursadas;
	
	
	
	public int getCodUniv() {
		return codUniv;
	}
	public void setCodUniv(int codUniv) {
		this.codUniv = codUniv;
	}
	public String getImagenUrl() {
		return imagenUrl;
	}
	public void setImagenUrl(String imagenUrl) {
		this.imagenUrl = imagenUrl;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public idioma[] getIdiomas() {
		return idiomas;
	}
	public void setIdiomas(idioma[] idiomas) {
		this.idiomas = idiomas;
	}
	public Asignatura[] getAsigCursadas() {
		return asigCursadas;
	}
	public void setAsigCursadas(Asignatura[] asigCursadas) {
		this.asigCursadas = asigCursadas;
	}
	
}
