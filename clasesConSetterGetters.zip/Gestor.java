package modelo;

public class Gestor extends Usuario {
	
}
